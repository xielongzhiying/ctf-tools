.. _artist-api:

*******
artists
*******

.. inheritance-diagram:: matplotlib.patches matplotlib.lines matplotlib.text matplotlib.offsetbox matplotlib.image
   :parts: 2

:mod:`matplotlib.artist`
========================

.. automodule:: matplotlib.artist
   :members:
   :undoc-members:
   :show-inheritance:

