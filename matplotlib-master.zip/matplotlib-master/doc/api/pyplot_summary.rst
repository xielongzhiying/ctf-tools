Plotting commands summary
=========================

.. currentmodule:: matplotlib.pyplot

.. autofunction:: plotting

.. autofunction:: colormaps
