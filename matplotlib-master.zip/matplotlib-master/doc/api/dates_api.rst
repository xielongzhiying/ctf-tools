*****
dates
*****

.. inheritance-diagram:: matplotlib.dates
   :parts: 1

:mod:`matplotlib.dates`
=======================

.. automodule:: matplotlib.dates
   :members:
   :undoc-members:
   :show-inheritance:
