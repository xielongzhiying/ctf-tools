
:mod:`matplotlib.backends.backend_pdf`
======================================

.. automodule:: matplotlib.backends.backend_pdf
   :members:
   :show-inheritance:
