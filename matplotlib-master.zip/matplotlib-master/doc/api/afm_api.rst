**********************************
afm (Adobe Font Metrics interface)
**********************************


:mod:`matplotlib.afm`
=====================

.. automodule:: matplotlib.afm
   :members:
   :undoc-members:
   :show-inheritance:
