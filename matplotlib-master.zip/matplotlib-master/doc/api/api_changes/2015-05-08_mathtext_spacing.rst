Improved spacing in mathtext
````````````````````````````

The extra space that appeared after subscripts and superscripts has
been removed.
