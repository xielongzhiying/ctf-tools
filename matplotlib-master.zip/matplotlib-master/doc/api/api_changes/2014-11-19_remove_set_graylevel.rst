Deprecated `GraphicsContextBase.set_graylevel`
``````````````````````````````````````````````

The `GraphicsContextBase.set_graylevel` function has been deprecated in 1.5 and
will be removed in 1.6.  It has been unused.  The
`GraphicsContextBase.set_foreground` could be used instead.
