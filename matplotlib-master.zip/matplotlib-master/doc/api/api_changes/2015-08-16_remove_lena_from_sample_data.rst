Removed `Lena` images from sample_data
``````````````````````````````````````

The ``lena.png`` and ``lena.jpg`` images have been removed from
matplotlibs sample_data directory. The images are also no longer
available from `matplotlib.cbook.get_sample_data`. We suggest using
`matplotlib.cbook.get_sample_data('grace_hopper.png')` or
`matplotlib.cbook.get_sample_data('grace_hopper.jpg')` instead.
