.. _axes_grid_users-guide-index:

################################################
  The Matplotlib AxesGrid Toolkit User's Guide
################################################

:Release: |version|
:Date: |today|

.. toctree::

    axes_divider.rst
    axisartist.rst

