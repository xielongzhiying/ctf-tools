Square Plot 
-------------------------

Square plot:

Implemented square plots feature as a new parameter in the axis function. When argument 'square' is specified, equal scaling is set, and the limits are set such that xmax-xmin == ymax-ymin.  

Example:

``ax.axis('square')``

