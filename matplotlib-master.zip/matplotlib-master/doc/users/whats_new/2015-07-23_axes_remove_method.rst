`ax.remove()` works as expected
-------------------------------

As with artists added to as `Axes`, `Axes` can be
removed from their figure via ``ax.remove()``
