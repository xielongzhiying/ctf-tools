Logit Scale
-----------

Added support for the 'logit' axis scale, a nonlinear transformation

.. math::

   x -> \log10(x / (1-x))

for data between 0 and 1 excluded.
