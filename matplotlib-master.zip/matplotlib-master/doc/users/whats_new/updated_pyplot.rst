Updated fignum_exists to take figure name
-------------------------------------------

Added the ability to check the existence of a figure using it's name
instead of just the figure number.
Example::

  figure('figure')
  fignum_exists('figure') #true
