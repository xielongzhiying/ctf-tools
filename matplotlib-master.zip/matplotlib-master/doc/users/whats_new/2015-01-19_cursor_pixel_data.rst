Allow Artists to Display Pixel Data in Cursor
---------------------------------------------

Adds `get_pixel_data` and `format_pixel_data` methods to artists
which can be used to add zdata to the cursor display
in the status bar.  Also adds an implementation for Images.
