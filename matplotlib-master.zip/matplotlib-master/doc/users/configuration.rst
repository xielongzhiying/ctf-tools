.. _configuration-guide-index:

###################
Configuration Guide
###################

.. htmlonly::

    :Release: |version|
    :Date: |today|

.. toctree::
    :maxdepth: 2

    installing.rst
    customizing.rst
    shell.rst



