#ifndef _JOHN_OPENCL_MASK_H
#define _JOHN_OPENCL_MASK_H

#define MASK_FMT_INT_PLHDR 		4

#endif
